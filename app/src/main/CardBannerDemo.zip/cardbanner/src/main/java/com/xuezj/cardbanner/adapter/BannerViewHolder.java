package com.xuezj.cardbanner.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by xuezj on 2017/7/29.
 */

public abstract class BannerViewHolder extends RecyclerView.ViewHolder {
    public BannerViewHolder(View itemView) {
        super(itemView);
    }
}
