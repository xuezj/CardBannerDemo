package com.xuezj.cardbanner;

/**
 * Created by xuezj on 2017/7/29.
 */

public abstract class BannerData {
}
